package csp;

/**
 * CSCI1130 Assignment 3 CSP Solver.
 *
 * I declare that the assignment here submitted is original
 * except for source material explicitly acknowledged,
 * and that the same or closely related material has not been
 * previously submitted for another course.
 * I also acknowledge that I am aware of University policy and
 * regulations on honesty in academic work, and of the disciplinary
 * guidelines and procedures applicable to breaches of such
 * policy and regulations, as contained in the website.
 *
 * University Guideline on Academic Honesty:
 *   http://www.cuhk.edu.hk/policy/academichonesty
 * Faculty of Engineering Guidelines to Academic Honesty:
 *   https://www.erg.cuhk.edu.hk/erg/AcademicHonesty
 *
 * Student Name: xxx <fill in yourself>
 * Student ID  : xxx <fill in yourself>
 * Date        : xxx <fill in yourself>
 */

/**
 * Constraint Satisfaction Problem Solver
 * @author pffung
 */
public class CSPSolver {

    // class field userWindow for keeping an object reference
    private static ConstraintInputBox userWindow;
    
    /**
     * Starting method of the application.
     * @param args is an array of command line arguments, not used here
     */
    public static void main(String[] args) {
        // create a new InputBox object, named userWindow
        userWindow = new ConstraintInputBox();
        
        // afterwards, the Java GUI system will take over the control
        
        // the following methods be invoked then
    }
    
    /**
     * The InputBox will handle user interactions.
     * On clicking the Randomize! button, CSPSolver.randomize() will be invoked.
     */
    public static void randomize() {
        // Students should complete this method to finish the assignment

        // Generate and set RANDOMLY Constraints 1 - 3 coefficients A, B, C.
        // The random number range is specified by the user.
        
        // sample statements for your reference:
        int minRandomRange = userWindow.getMinRandomRange();
        int maxRandomRange = userWindow.getMaxRandomRange();
        
        // dummy examples:
        userWindow.set1A(minRandomRange);
        userWindow.set1B(maxRandomRange);
        userWindow.set1C(minRandomRange);
        
        userWindow.set2A(maxRandomRange);
        userWindow.set2B(maxRandomRange);
        userWindow.set2C(minRandomRange);
        
        userWindow.set3A(minRandomRange);
        userWindow.set3B((minRandomRange + maxRandomRange) / 2);
        userWindow.set3C(maxRandomRange);
        
    }

    /**
     * The InputBox will handle user interactions.
     * On clicking the Solve! button, CSPSolver.calculate() will be invoked.
     */
    public static void calculate() {
        // Students should complete this method to finish the assignment
        
        // sample statements for your reference:
        // To get coefficients of the contraint equations on userWindow.
        int c1A = userWindow.get1A();
        int c1B = userWindow.get1B();
        int c1C = userWindow.get1C();
        // ...
        
        
        
        // declare object variables, and
        // create three Constraint equation objects
        // labelled as "First", "Second" and "Third"
        Constraint c1;
        Constraint c2;
        Constraint c3;
        c1 = new Constraint("First", c1A, c1B, c1C);
        // ...
        

        
        // Generate-and-Test
        // evaluate the Constraint equations with proposed solutions
        int x, y, z;

        // SAMPLE code with an EXAMPLE x, y, z combination for your reference
        x = 7;
        y = 9;
        z = 9;
        System.out.printf("Combination (x = %d, y = %d, z = %d): ", x, y, z);
        if (c1.evaluate(x, y, z))
        {
            System.out.println("Satisfies " + c1.getLabel() + " Constraint " + c1.toString());
            userWindow.displaySolution(x, y, z);
        }
        else
        {
            // c1.toString() will be invoked implicitly when we "print" an object
            System.out.println("Failed " + c1.getLabel() + " Constraint " + c1);
            userWindow.displayNoSolution();
        }
        
        // try different combinations of x, y, z
        // test c1 AND c2 AND c3
        
        // println/ printf statements are optional
        // display your result on userWindow
        
    }
}
