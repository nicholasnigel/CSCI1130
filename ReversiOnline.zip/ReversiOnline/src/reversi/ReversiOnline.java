package reversi;

import java.io.PrintStream;
import java.net.URL;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * ReversiOnline is an extension to Reversi
 * 
 * Student Name:
 * Student ID  :
 * Date        :
 * 
 * Declaration Statement on Academic Honesty
 * 
 * @author pffung
 */
public class ReversiOnline extends Reversi {
    
    public static final String saveGameFilename = "reversi.txt";
    protected PrintStream gameFileStream;
    
    /*
     * Default constructor initializing a new board in this student app
     */
    public ReversiOnline() {
        // invoke default constructor of the super-class
        super();
        
        // ask user for Initial Reversi Game Board URL
        String address = "http://www.cse.cuhk.edu.hk/~pffung/reversi2.txt";
        while (true) {
            gameBoard.addText("Waiting for game board URL...");

            address = JOptionPane.showInputDialog("Initial Reversi Game Board URL", address);

            if (address == null) 
            {
                gameBoard.addText("Cancelled loading game board");
                break;
            }

            gameBoard.addText("Trying to load board from " + address);

            if (loadGameBoard(address))
            {
                gameBoard.addText("Game board loaded");

                gameBoard.updateStatus(pieces, currentPlayer);

                // sanity check to see if the initial game has ended!
                // the following method is available in super-class
                passAndEndGameCheck();
                break;
            }
            else
                gameBoard.addText("Failed to load game board");
        }
        
        
        // Student's work here

        // create the gameFileStream using the default saveGameFilename
        // if it fails, copy System.out to gameFileStream






        
        // save the initial game board
        saveGameBoard(gameFileStream);
    }
    
    /*
     * Callback method will be invoked to handle user click
     * Add new feature: save the new valid move and the updated game board to file
     *
     * Overriden: to add save game feature on each valid move
     *
     * Student's work here
     */
    @Override
    public void userClicked(int row, int col)
    {
        // the following method is available in super-class
        if (conquerCheck(row, col, true))
        {
            pieces[row][col] = currentPlayer;
            currentPlayer = FLIP * currentPlayer;
            gameBoard.updateStatus(pieces, currentPlayer);

            /* Student's work here */
            
            String aLineToWriteTo_gameFileStream = "Move (" + row + ", " + col + ")";

            // write the above line to gameFileStream
            // and save game board to gameFileStream
            
            
            
            
            
            
            
            
            // the following method is available in super-class
            passAndEndGameCheck();
        }
        else
            gameBoard.addText("Invalid move");
    }
    

    /*
     * Load and store a game board from the given URL address to pieces[][]
     * Student's work here
     */
    protected boolean loadGameBoard(String address)
    {
// Students have not yet completed this method, DEBUG mode: return false
boolean DEBUG = true;
if (DEBUG) return false;
        
        
        
        if (address == null) return false;
    
        int[][] config = null;
        int player = '?';
        
        try {










            
            
            
            




        }
        catch (Exception e)
        {
            return false;
        }

        pieces = config;
        currentPlayer = player;
        return true;
    }
    
    /*
     * Save a game board
     * Student's work here
     */
    protected void saveGameBoard(PrintStream outputStream)
    {






















    }
            
    /* New application starts here */
    public static void main(String[] args) {
        Reversi game = new ReversiOnline();
    }

}
